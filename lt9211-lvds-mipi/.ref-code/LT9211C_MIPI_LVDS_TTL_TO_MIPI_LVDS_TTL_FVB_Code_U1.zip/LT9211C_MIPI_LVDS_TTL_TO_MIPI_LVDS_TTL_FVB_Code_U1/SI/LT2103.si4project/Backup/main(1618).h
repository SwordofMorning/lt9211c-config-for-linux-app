
#ifndef _MAIN_H
#define _MAIN_H

#define _uart_debug_


#define          LT9211INPUT          LVDS_IN //LVDS_IN/MIPI_IN/TTL_IN

#define          LT9211OUTPUT         LVDS_OUT //LVDS_OUT/MIPI_OUT/TTL_OUT



#endif

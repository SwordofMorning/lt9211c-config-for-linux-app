#include	"include.h"

#ifndef		_DRVCSC_H
#define		_DRVCSC_H


extern void Drv_Csc_Set(void);
#endif

#ifndef 	_OCMDELAY_H
#define 	_OCMDELAY_H


extern void Ocm_Timer0_Delay100us(u32 ulCnt);
extern void Ocm_Timer0_Delay1ms(u32 ulCnt);


#endif

